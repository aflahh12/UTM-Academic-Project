TITLE lab_3_part_2c

; Author: Nabil Aflah
; Date: 28 June 2024


INCLUDE Irvine32.inc

.data
msgMain BYTE "Welcome to Simple Math Activities:", 0dh, 0ah, 0dh, 0ah
BYTE "Main Menu", 0dh, 0ah, 0dh, 0ah
BYTE "1. To calculate Perimeter Hexagon (Loop and ADD instructions)", 0dh, 0ah
BYTE "2. To calculate SUM(unsign int) index (Odd or Even) in an Array Hello [6]", 0dh, 0ah, 0
mesIn BYTE "Select Your Input: ", 0
decNumOption DWORD ?
promptBad BYTE "Invalid input, please enter again", 0

message BYTE "Calculate Perimeter 2-Hexagon (LOOP and ADD instructions):", 0dh, 0ah, 0
message1 BYTE "Input Hexagon 1 (side length) : ", 0
message2 BYTE "Input Hexagon 2 (side length) : ", 0

sideHex1 DWORD ?
sideHex2 DWORD ?

message3 BYTE "Result of Perimeter Hexagon 1 and 2: ", 0
Perimeter_hexagon1 DWORD ?
Perimeter_hexagon2 DWORD ?
message4 BYTE "Total Perimeter Hexagon 1 and 2: ", 0
TotalPerimeter DWORD ?

prompt BYTE "Calculate SUM (unsign INT) index (Odd or Even) in array Hello[6] :", 0dh, 0ah, 0
inputMsg BYTE "Interger Input : ", 0
hello DWORD 6 DUP(0)

totalEven DWORD ?
totalOdd DWORD ?

resultMsg BYTE "Result Sum Hello[index]:", 0dh, 0ah, 0
sumEvenMsg BYTE "Sum Hello[even] index location : ", 0
sumOddMsg BYTE "Sum Hello[odd] index location : ", 0

strYorN BYTE "Press 'y' to Main Menu or 'n' to Exit the benchmark : ", 0
charIn BYTE ?
charY db "y"
strBye BYTE "Thank you...BYE!!", 0dh, 0ah, 0

.code
main PROC

	startProg :
	call Clrscr
	mov edx, offset msgMain
	call WriteString

	call Crlf

	mov edx, offset mesIn
	call WriteString; go input main menu

	read_InOption :
	call ReadDec
	jnc goodInOption

	mov edx, OFFSET promptBad
	call WriteString
	jmp read_InOption; go input again

	goodInOption :
	mov decNumOption, eax

	mov ebx, 1
	cmp eax, ebx
	je periHex_loopAdd

	mov ebx, 2
	cmp eax, ebx
	je calSum_oddeven

	jmp startProg; if input is invalid, go back to startProg

	periHex_loopAdd :
	call Clrscr
	mov edx, OFFSET message
	call WriteString
	call crlf
	call crlf

	; Input for hex1(sidelength)
	mov edx, OFFSET message1
	call WriteString
	call ReadDec
	mov sideHex1, eax

	; Input for hex2(sidelength)
	mov edx, OFFSET message2
	call WriteString
	call ReadDec
	mov sideHex2, eax

	; Calculate perimeter for Hexagon 1
	mov eax, sideHex1
	mov ecx, 6
	mul ecx
	mov Perimeter_hexagon1, eax

	; Calculate perimeter for Hexagon 2
	mov eax, sideHex2
	mov ecx, 6
	mul ecx
	mov Perimeter_hexagon2, eax

	; Add both perimeters
	mov eax, Perimeter_hexagon1
	add eax, Perimeter_hexagon2
	mov TotalPerimeter, eax

	; Display results

	call crlf
	mov edx, OFFSET message3
	call WriteString
	call crlf

	; Display Perimeter of Hexagon 1
	mov eax, Perimeter_hexagon1
	call WriteDec
	call crlf

	; Display Perimeter of Hexagon 2
	mov eax, Perimeter_hexagon2
	call WriteDec
	call crlf

	; Display total perimeter

	call Crlf
	mov edx, OFFSET message4
	call WriteString
	mov eax, TotalPerimeter
	call WriteDec
	call Crlf

	; ask either to go main menu 'y' or exit benchmark 'n'

	mov edx, OFFSET strYorN
	call WriteString

	call ReadChar
	mov charIn, AL
	call WriteChar
	call Crlf
	call Crlf

	cmp charIn, 'y'
	JE startProg

	call Crlf
	mov edx, OFFSET strBye
	call WriteString
	exit

	calSum_oddeven :
	call Clrscr
	mov edx, OFFSET prompt
	call WriteString
	call crlf
	call crlf

	; Input loop to get 6 values from the user
	mov ecx, 6; loop counter for 6 values
	mov esi, 0; index for hello array

	inputLoop:
	mov edx, OFFSET inputMsg; display "Integer Input : "
	call WriteString
	call ReadInt; read integer input from user
	mov[hello + esi], eax; store the input in hello array
	add esi, 4; move to the next DWORD
	loop inputLoop; repeat for all elements

	; Initialize totalEvenand totalOdd to 0
	xor eax, eax
	mov totalEven, eax
	mov totalOdd, eax

	; Calculate the sum of even - indexed and odd - indexed elements
	mov ecx, 6; loop counter for 6 values
	xor esi, esi; index for hello array

	sumLoop:
	mov eax, [hello + esi]
	test esi, 4; check if the index is even or odd
	jz evenIndex

	; Odd index
	add totalOdd, eax
	jmp nextElement

	evenIndex :
	; Even index
	add totalEven, eax

	nextElement :
	add esi, 4; move to the next DWORD
		loop sumLoop; repeat for all elements

		; Display results
		call crlf
		mov edx, OFFSET resultMsg
		call WriteString
		call crlf
		call crlf

		; Display the sum of even - indexed elements
		mov edx, OFFSET sumEvenMsg
		call WriteString
		mov eax, totalEven
		call WriteDec
		call crlf
		call crlf

		; Display the sum of odd - indexed elements
		mov edx, OFFSET sumOddMsg
		call WriteString
		mov eax, totalOdd
		call WriteDec
		call crlf
		call crlf

		; ask either to go main mmenu 'y' or exit benchmark 'n'
		
		mov edx, OFFSET strYorN
		call WriteString

		call ReadChar
		mov charIn, AL
		call WriteChar
		call Crlf
		call Crlf

		cmp BL, charY
		cmp BL, charIn
		JE startProg

		call Crlf
		mov edx, OFFSET strBye
		call WriteString

exit

main endp

END main

