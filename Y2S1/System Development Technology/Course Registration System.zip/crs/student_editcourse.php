<?php 
include('crs_session.php');
// checkUserAccess("2");

if(!session_id())
{
  session_start();
}

include 'headerstudent.php';
include 'db_connect.php';

//validate and fetch course details
if(isset($_GET['tid'])) {
    die("Invalid request");
}

$transactionID = $_GET['tid'];

//fetch course details
$query = "SELECT r.*, c.c_name, c.c_code, c.c_credit
          FROM tb_registration r
          LEFT JOIN tb_course c ON r.r_course = c.c_code
          WHERE r.r_id = ?";
$stmt = mysqli_prepare($con, $query);
mysqli_stmt_bind_param($stmt, "i", $transactionID);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$course = mysqli_fetch_assoc($result);

if(!$course){
    $_SESSION['message'] = "No such course found!";
    $_SESSION['message_type'] = "danger";
    header('Location: student_courseregister.php');
    exit();
}

//fetch available section
$section_query = "SELECT DISTINCT r_section FROM tb_registration WHERE r_course = ?";
$section_stmt = mysqli_prepare($con, $section_query);
mysqli_stmt_bind_param($section_stmt, "s", $course['c_code']);
mysqli_stmt_execute($section_stmt);
$section_result = mysqli_stmt_get_result($section_stmt);
?>

<div class="container mt-5">
    <h3>Edit Course Registration</h3>

    <form action="student_editcourseprocess.php" method="POST">
        <input type="hidden" name="tid" value="<?= $transactionID; ?>">
        <div class="mb-3">
            <label class="form-label">Course Code</label>
            <input type="text" class="form-control" value="<?= $course['c_code']; ?>" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label">Course Name</label>
            <input type="text" class="form-control" value="<?= $course['c_name']; ?>" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label">Credit Hours</label>
            <input type="text" class="form-control" value="<?= $course['c_credit']; ?>" readonly>
        </div>
        <div class="mb-3">
            <label for="section" class="form-label">Section</label>
            <select class="form-select" id="section" name="section" required>
                <option value="">Select Section</option>
                <?php while($section = mysqli_fetch_assoc($section_result)): ?>
                    <option value="<?= $section['r_section']; ?>"<?= ($section['r_section'] == $course['r_section']) ? 'selected' : ''; ?>>
                        <?= $section['r_section']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Update</button>
        <a href="student_courseregister.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?php include 'footer.php'; ?>