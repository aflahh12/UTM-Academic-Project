<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'db_connect.php';
include 'headeradvisor.php';

//fetch available semester
$semesters = mysqli_query($con, "SELECT DISTINCT c_sem FROM tb_course ORDER BY c_sem DESC");
$semester_list = mysqli_fetch_all($semesters, MYSQLI_ASSOC);

//determine the selected course
$selected_sem = $_GET['semester'] ?? ($semester_list[0]['c_sem'] ?? date('Y') . '/' . (date('Y') + 1) . '-' . (date('n') <= 6 ? '1' : '2')) ;

//fetch courses
$query = "SELECT c_code, c_name, c_credit, c_lec, c_maxstudent, c_section FROM tb_course WHERE c_sem = ?";
$stmt = mysqli_prepare($con, $query);
mysqli_stmt_bind_param($stmt, "s", $selected_sem);
mysqli_stmt_execute($stmt);
$courses = mysqli_stmt_get_result($stmt);
?>

<div class="container">
    <div class="d-flex justify-content-between mb-3">
        <a href="advisor.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i>Back</a>
        <h2>Course List</h2>
        <a href="admin_addcourse.php" class="btn btn-primary"><i class="fas fa-plus"></i>Add Course</a>
    </div>


    <?php if(!empty($_SESSION['message'])): ?>
    <div class="alert alert-<?= htmlspecialchars($_SESSION['message_type']) ?> alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($_SESSION['message']); unset($_SESSION['message'], $_SESSION['message_type']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5>Semester: <?= htmlspecialchars($selected_sem) ?></h5>
            <form method="GET">
                <select name="semester" class="form-select" onchange="this.form.submit()">
                    <?php foreach($semester_list as $sem): ?>
                    <option value="<?= htmlspecialchars($sem['c_sem']); ?>" <?= $selected_sem == $sem['c_sem'] ? 'selected' : ''; ?>>
                        <?= htmlspecialchars($sem['c_sem']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>
        <div class="card-body">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Course Code</th>
                        <th>Course Name</th>
                        <th>Credit</th>
                        <th>Lecturer</th>
                        <th>Max Student</th>
                        <th>Section</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                   <?php $i=1; while($row = mysqli_fetch_assoc($courses)): ?>
                    <tr>
                        <td><?= $i++; ?></td>
                        <td><?= htmlspecialchars($row['c_code']); ?></td>
                        <td><?= htmlspecialchars($row['c_name']); ?></td>
                        <td><?= htmlspecialchars($row['c_credit']); ?></td>
                        <td><?= htmlspecialchars($row['c_lec']); ?></td>
                        <td><?= htmlspecialchars($row['c_maxstudent']); ?></td>
                        <td><?= htmlspecialchars($row['c_section']); ?></td>
                        <td>
                            <a href="admin_editcourse.php?code=<?= urlencode($row['c_code']); ?>&section=<?= urlencode($row['c_section']); ?>" class="btn btn-sm btn-primary">Edit</a>
                            <button class="btn btn-sm btn-danger" onclick="confirmDelete('<?= urlencode($row['c_code']); ?>','<?= urlencode($row['c_section']); ?>')">Delete</button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- delete confirmation script -->
    <script>
        function confirmDelete(code, section) {
            if(confirm('Are you sure you want to delete this course?')) {
                window.location.href = `deletecourse.php?code=${encodeURIComponent(code)}&section=${encodeURIComponent(section)}`;
            }
        }
    </script>

<?php include 'footer.php';?>