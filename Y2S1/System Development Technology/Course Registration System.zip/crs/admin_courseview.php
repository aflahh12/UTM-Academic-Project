<?php 
// include('crs_session.php');

// if(!session_id())
// {
//   session_start();
// }

// include 'headeradvisor.php';
// include 'db_connect.php';

// //get user id
// $uic = $_SESSION['funame'];

// //retrieve all courses
// $sql = "SELECT * FROM tb_course
//         LEFT JOIN tb_user ON tb_course.c_lec = tb_user.u_sno";

// $result = mysqli_query($con, $sql);
?>

<!-- <div class="container"> -->

    <!-- <table class="table table-striped table-light">
      <thead>
      <th scope="col">Course Code</th>
      <th scope="col">Course Name</th>
      <th scope="col">Credit Hours</th>
      <th scope="col">Lecturer</th>
      <th scope="col">Operation</th> -->
    <!-- </tr>
  </thead>
  <tbody> -->
    <?php
    // while($row = mysqli_fetch_array($result))
    // {
    //   echo"<tr>";
    //     echo"<td>".$row['c_code']."</td>";
    //     echo"<td>".$row['c_name']."</td>";
    //     echo"<td>".$row['c_credit']."</td>";
    //     echo"<td>".$row['u_name']."</td>";
    //     echo"<td>";
    //     echo"<a href='admin_deletecourse.php?c_code=".$row['c_code']."' 
    //             onclick='return confirm(\"Are you sure you want to delete this course?\");' 
    //             class= 'btn btn-danger'>Delete</a>";
    //     echo"</td>";
    //     echo"<tr>";
    // }
    ?>
  <!-- </tbody>
</table>
</div> -->