<?php 
include('crs_session.php');
// checkUserAccess("2");

if(!session_id())
{
  session_start();
}

include 'headerstudent.php';
include 'db_connect.php';

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['course'])){
    $student_id = $_SESSION['funame'] ?? '';
    $course = $_POST['course'];
    $sem = $_POST['sem'] ?? '';

    // var_dump($student_id);
    // var_dump($course);
    // exit();

    if(empty($student_id)) {
        $_SESSION['message'] = "Student ID not found.";
        $_SESSION['message_type'] = "danger";
        header('Location: student_addcourse.php');
        exit();
    }

    $success = 0;
    $failed = 0;

    foreach ($course as $course_code) {
        //check if course is already registered
        echo "Checking if course {$course_code} is registered...<br>";

        $check_query = "SELECT * FROM tb_registration WHERE r_student = ? AND r_course = ?";
        $check_stmt = mysqli_prepare($con, $check_query);
        mysqli_stmt_bind_param($check_stmt, "ss", $student_id, $course_code);
        mysqli_stmt_execute($check_stmt);
        $check_result = mysqli_stmt_get_result($check_stmt);

        if(mysqli_num_rows($check_result) == 0) {
            $section = "01";

            $insert_query = "INSERT INTO tb_registration (r_student, r_course, r_section, r_sem, r_status) VALUES (?, ?, ?, ?, 1)";
            $insert_stmt = mysqli_prepare($con, $insert_query);
            mysqli_stmt_bind_param($insert_stmt, "ssss", $student_id, $course_code, $section, $sem);
            
            if(mysqli_stmt_execute($insert_stmt)){
                //after successful registration, update the enrollment
                // $update_enrollment = "UPDATE tb_course SET enrolled = (SELECT COUNT (*) FROM tb_registration WHERE r_course = ? AND r_status = 2) WHERE c_code = ?";
                // $update_stmt = mysqli_prepare($con, $update_enrollment);
                // mysqli_stmt_bind_param($update_stmt, "ss", $course_code, $course_code);
                // mysqli_stmt_execute($update_stmt);

                $success++;
            } else {
                $failed++;
                echo "Error: " .mysqli_error($con);
            }
        } else {
            $failed++;
            echo "Course {$course_code} already registered.<br>";
        }
    }

        if($success > 0) {
            $_SESSION['message'] = "Course registration successful!";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Course registration failed!";
            $_SESSION['message_type'] = "danger";
        }
} else {
        $_SESSION['message'] = "No course selected!";
        $_SESSION['message_type'] = "danger";
}

header('Location: student_addcourse.php');
exit();
?>
