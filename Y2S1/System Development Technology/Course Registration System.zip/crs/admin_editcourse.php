<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'db_connect.php';
include 'headeradvisor.php';

$code = $_GET['code'] ?? '';
$section = $_GET['section'] ?? '';

$course = null;
if($code && $section){
    $query = "SELECT * FROM tb_course WHERE c_code = ? AND c_section = ?";
    $stmt = mysqli_prepare($con, $query);
    
    if (!$stmt) {
        die('Query preparation failed: ' . mysqli_error($con));
    }

    mysqli_stmt_bind_param($stmt, "ss", $code, $section);    
    if (!mysqli_stmt_execute($stmt)) {
      die('Query execution failed: ' . mysqli_stmt_error($stmt));
    }
  
    $course = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    
    // mysqli_stmt_execute($stmt);
    // $course = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    
}

$semester = mysqli_query($con, "SELECT DISTINCT c_sem FROM tb_course ORDER BY c_sem DESC");
$semester_list = mysqli_fetch_all($semester, MYSQLI_ASSOC);

$default_sem = date('Y') . '/' . (date('Y') + 1) . '-' . (date('n') <= 6 ? '1' : '2');

if($_SERVER['REQUEST_METHOD'] == 'POST') {
  $query = "UPDATE tb_course SET c_name = ?, c_credit = ?, c_lec = ?, c_maxstudent = ?, c_sem = ? WHERE c_code = ? AND c_section = ?";
  $stmt = mysqli_prepare($con, $query);
  mysqli_stmt_bind_param($stmt, "sisisss", $_POST['course_name'], $_POST['credit_hours'], $_POST['lecturer'], $_POST['max_students'], $_POST['semester'], $code, $section);

  if(mysqli_stmt_execute($stmt)){
    $_SESSION['message'] = "Course updated successfully!";
    $_SESSION['message_type'] = "success";
  } else {
    $_SESSION['message'] = "Error updating course: " .mysqli_error($con);
    $_SESSION['message_type'] = "danger";
  }
  header("Location: admin_courselist.php");
  exit();
}
?>

<div class="container">
  <a href="javascript:history.back()" class="btn btn-secondary mt-3"><i class="fas fa-arrow-left"></i> Back</a>
  <h2>Edit Course</h2>

  <?php if(isset($_SESSION['message'])): ?>
    <div class="alert alert-<?= $_SESSION['message_type'] ?> alert-dismissible fade show mt-3" role="alert">
      <?= $_SESSION['message']; unset($_SESSION['message'], $_SESSION['message_type']); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
  <?php endif; ?>

  <div class="card">
    <div class="card-header bg-primary text-white">Course Details</div>
    <div class="card-body">
      <?php if ($course): ?>
        <form method="POST" onsubmit="confirmUpdate(event)">
          <input type="hidden" name="code" value="<?= htmlspecialchars($code); ?>">
          <input type="hidden" name="section" value="<?= htmlspecialchars($section); ?>">

          <label>Course Code</label>
          <input type="text" class="form-control mb-3" value="<?= htmlspecialchars($course['c_code']); ?>" readonly>

          <label>Course Name</label>
          <input type="text" class="form-control mb-3" name="course_name" value="<?= htmlspecialchars($course['c_name']); ?>" required>

          <label>Credit Hours</label>
          <select class="form-select mb-3" name="credit_hours" required>
            <?php for($i=1; $i <= 4; $i++): ?>
              <option value="<?= $i; ?>" <?= $course['c_credit'] == $i ? 'selected' : ''; ?>><?= $i; ?></option>
            <?php endfor; ?>
          </select>

          <label>Lecturers</label>
          <input type="text" class="form-control mb-3" name="lecturer" value="<?= htmlspecialchars($course['c_lec']); ?>"pattern="[A-Za-z]{1,2}[0-9]{3}" required>

          <label>Section</label>
          <input type="text" class="form-control mb-3" name="section" value="<?= htmlspecialchars($course['c_section']); ?>" readonly>

          <label>Max Students</label>
          <input type="number" class="form-control mb-3" name="max_students" value="<?= htmlspecialchars($course['c_maxstudent']); ?>" min="1" max="50" required>

          <label>Semester</label>
          <select class="form-select mb-3" name="semester" required>
            <?php foreach($semester_list as $sem): ?>
              <option value="<?= htmlspecialchars($sem['c_sem']); ?>" <?= $course['c_sem'] == $sem['c_sem'] ? 'selected' : ''; ?>><?= $sem['c_sem']; ?></option>
            <?php endforeach; ?>
          </select>

          <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
          <a href="admin_courselist.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
        </form>
      <?php else: ?>
        <div class="alert alert-danger mt-3">Course not found!</div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
  function confirmUpdate(event){
    if(!confirm('Are you sure you want to update this course?')){
      event.preventDefault();
    }
  }
</script>

<?php include 'footer.php'; ?>