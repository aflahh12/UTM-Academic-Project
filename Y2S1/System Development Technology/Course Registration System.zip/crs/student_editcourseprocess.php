<?php 
include('crs_session.php');
// checkUserAccess("2");

if(!session_id())
{
  session_start();
}

include 'headerstudent.php';
include 'db_connect.php';

if($_SESSION["REQUEST_METHOD"] == "POST" && isset($_POST['tid']) && isset($_POST['section'])) {
    $transactionID = $_POST['tid'];
    $section = $_POST['section'];

    $update_query = "UPDATE tb_registration SET r_section = ? WHERE r_id = ?";
    $stmt = mysqli_prepare($con, $update_query);
    mysqli_stmt_bind_param($stmt, "si", $section, $transactionID);

    if(mysqli_stmt_execute($stmt)){
        $_SESSION['message'] = "Course registration updated successfully!";
        $_SESSION['message_type'] = "success";
        header('Location: student_courseregister.php');
        exit();
    } else {
        $_SESSION['message'] = "Error updating course registration: " .mysqli_error($con);
        $_SESSION['message_type'] = "danger";
    }

    header('Location: student_courseregister.php');
    exit();
    } else {
        die("Invalid request");
}