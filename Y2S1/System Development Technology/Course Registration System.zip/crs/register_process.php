<?php
//Connect to DB
include('db_connect.php');

if($_SERVER["REQUEST_METHOD"] == "POST"){
		//Retrieve data from  form
	$funame = mysqli_real_escape_string($con, $_POST['funame']); 
	$fpwd = mysqli_real_escape_string($con, $_POST['fpwd']);
	$femail = mysqli_real_escape_string($con, $_POST['femail']);
	$fname = mysqli_real_escape_string($con, $_POST['fname']);
	$fcontact = mysqli_real_escape_string($con, $_POST['fcontact']);
	$fstate = mysqli_real_escape_string($con, $_POST['fstate']);
	$frole = mysqli_real_escape_string($con, $_POST['frole']);

	//hash password
	// $hashedpwd = password_hash($fpwd, PASSWORD_DEFAULT);

	//SQL Insert operation
	$sql = "INSERT INTO tb_user(u_sno, u_pwd, u_email, u_name, u_contact, u_state, u_reg, u_utype)
			VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP(), ?)";

	//Execute SQL
	$stmt = mysqli_prepare($con, $sql);

	if($stmt) {
		mysqli_stmt_bind_param($stmt, "ssssssi", $funame, $fpwd, $femail, $fname, $fcontact, $fstate, $frole);
		$result = mysqli_stmt_execute($stmt);

		if($result) {
			$_SESSION['message'] = "Registration successful!";
		} else {
			$_SESSION['message'] = "Error: Could not register.";
		}

		mysqli_stmt_close($stmt);
	} else {
		$_SESSION['message'] = "Error preparing sql statement.";
	}

	//Close connection
	mysqli_close($con);

	//Redirect user to login
	header('Location: login.php');
	exit();
}
?>