<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'headerlecturer.php';
include 'db_connect.php';

//Get user ID
$lec_id = $_SESSION['funame'];

//fetch list of courses that assigned to the lecturer
$courses = [];
$course_query = "SELECT DISTINCT c_code, c_name, c_section FROM tb_course WHERE c_lec = ? ORDER BY c_code ASC, c_section ASC";
$stmt = mysqli_prepare($con, $course_query);
mysqli_stmt_bind_param($stmt, "s", $lec_id);
mysqli_stmt_execute($stmt);
$course_result = mysqli_stmt_get_result($stmt);

while($course = mysqli_fetch_assoc($course_result)){
    $courses[] = $course;
}

//get selected course and section
$course_details = isset($_GET['course']) ? explode('|', $_GET['course']) : ['ALL', 'ALL'];
$selected_course = $course_details[0];
$selected_section = $course_details[1];
?>

<div class="container mt-4">
    <h2 class="mb-3">Student Information</h2>

    <!-- course filter form -->
     <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row">
                <div class="col-md-4">
                    <label for="course" class="form-label">Choose course and section:</label>
                    <select name="course" id="course" class="form-select" required>
                        <option value="ALL|ALL" <?= $selected_course == 'ALL' ? 'selected' : ''; ?>>All Students</option>
                        <?php foreach($courses as $course): ?>
                            <option value="<?php echo $course['c_code'] . '|' . $course['c_section']; ?>" 
                                    <?php echo($selected_course == $course['c_code'] && $selected_section == $course['c_section']) ? 'selected' : ''; ?>>
                                <?php echo$course['c_code'] . ' - ' . $course['c_name'] . ' (Section ' . $course['c_section'] . ')'; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary mt-4">Filter students</button>
                </div>
            </form>
        </div>
    </div>

    <?php
    //if the course is selected, retrieve students for that course
    if($selected_course) {
        if($selected_course == 'ALL') {
            $student_query = "SELECT u.u_sno, u.u_name, u.u_email, 
                              GROUP_CONCAT(DISTINCT CONCAT(c.c_code, ' (', c.c_section, ')') ORDER BY c.c_code ASC SEPARATOR ', ') as courses, 
                              GROUP_CONCAT(DISTINCT r.r_status ORDER BY c.c_code SEPARATOR ', ') as status
                              FROM tb_user u
                              LEFT JOIN tb_registration r ON u.u_sno = r.r_student
                              LEFT JOIN tb_course c ON r.r_course = c.c_code
                              WHERE c.c_lec = ?
                              GROUP BY u.u_sno, u.u_name, u.u_email
                              ORDER BY u.u_name ASC";
            $stmt = mysqli_prepare($con, $student_query);
            mysqli_stmt_bind_param($stmt, "s", $lec_id);
        } else {
            $student_query = "SELECT u.u_sno, u.u_name, u.u_email, CONCAT(c.c_code, ' (', c.c_section, ')')  as course_info
                              FROM tb_user u
                              LEFT JOIN tb_registration r ON u.u_sno = r.r_student
                              LEFT JOIN tb_course c ON r.r_course = c.c_code
                              WHERE c.c_lec = ? AND c.c_code = ? AND c.c_section = ?
                              ORDER BY u.u_sno ASC";
            $stmt = mysqli_prepare($con, $student_query);
            mysqli_stmt_bind_param($stmt, "sss", $lec_id, $selected_course, $selected_section);
        }
        mysqli_stmt_execute($stmt);
        $students = mysqli_stmt_get_result($stmt);
    }
    ?>

    <!-- students list -->
     <div class="card">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0">
                <?php echo $selected_course == 'ALL' ? 'All Students' : "Students for " . $selected_course." (Section".$selected_section.")"; ?>
            </h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Email</th>
                            <th>Courses</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($students) > 0): ?>
                            <?php $i = 1; while($student = mysqli_fetch_assoc($students)): ?>
                                <tr>
                                    <td><?= $i++; ?></td>
                                    <td><?= htmlspecialchars($student['u_sno']); ?></td>
                                    <td><?= htmlspecialchars($student['u_name']); ?></td>
                                    <td><?= htmlspecialchars($student['u_email']); ?></td>
                                    <td>
                                        <?php if($selected_course == 'ALL'): ?>
                                            <?= htmlspecialchars($student['courses']); ?>
                                        <?php else: ?>
                                            <span class="badge <?php
                                                if(isset($student['r_status'])){
                                                    echo $student['r_status'] == 'Approved' ? 'bg-success' : 
                                                        ($student['r_status'] == 'Rejected' ? 'bg-danger' : 'bg-warning');
                                                } else {
                                                    echo 'bg-secondary';
                                                }
                                            ?>">
                                            <?php echo isset($student['r_status']) ? htmlspecialchars($student['r_status']) : 'No status'; ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="lecturer_viewstudentdetails.php?id=<?= $student['u_sno']; ?>&course=<?= $courseCode; ?>&section=<?= $section; ?>" class="btn btn-sm btn-info">View Details</a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center">No students is found.</td>
                                </tr>
                            <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

