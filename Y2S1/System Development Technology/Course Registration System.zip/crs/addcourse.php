<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

// if($_SESSION['u_utype'] != 3){
//     $_SESSION['error'] = "Unauthorized access";
//     header('Location: login.php');
//     exit();
// }

include 'headeradvisor.php';
include 'db_connect.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $course_code = $_POST['c_code'];
    $course_name = $_POST['c_name'];
    $course_credit = $_POST['chours'];
    $course_sem = $_POST['sem'];

    $insert_query = "INSERT INTO tb_course (c_code, c_name, c_credit, c_sem) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($con, $insert_query);
    mysqli_stmt_bind_param($stmt, "ssis", $course_code, $course_name, $course_credit, $course_sem);

    if(mysqli_stmt_execute($stmt)){
        //success message
        $_SESSION['success'] = "Course added successfully!";

        //insert each section
        if(isset($_POST['secNo'])) {
            for($i = 0; $i < count($_POST['secNo']); $i++) {
                $section_no = $_POST['secNo'][$i];
                $max_students = $_POST['secMaxStudent'][$i];
                $lec_name = $_POST['sec_lec'][$i];

                //validate of the lecturer exists in tb_user
                $lec_query = "SELECT * FROM tb_user WHERE u_sno = ?";
                $lec_stmt = mysqli_prepare($con, $lec_query);
                mysqli_stmt_bind_param($lec_stmt, "s", $lec_name);
                mysqli_stmt_execute($lec_stmt);
                $lec_result = mysqli_stmt_get_result($lec_stmt);

                if(mysqli_num_rows($lec_result) == 0){
                    $_SESSION['error'] = "Lecturer with ID $lec_name not found!";
                    header('Location: addcourse.php');
                    exit();
                }

                $insert_section_query = "INSERT INTO tb_course (c_section, c_maxstudent, c_lec, c_code) VALUES (?, ?, ?, ?)";
                $stmt = mysqli_prepare($con, $insert_section_query);
                mysqli_stmt_bind_param($stmt, "siss", $section_no, $max_students, $lec_name, $course_code);
                if(!mysqli_stmt_execute($stmt)){
                    $_SESSION['error'] = "Error adding section!";
                    header('Location: addcourse.php');
                    exit();
                }
            }
        }
        header('Location: admin_courselist.php');
        exit();
    } else {
        $_SESSION['error'] = "Error adding course!";
        header('Location: addcourse.php');
        exit();
    }
}

?>
<script>
    function addSection(){
        let sectionContainer = document.getElementById('section-container');
        let sectionIndex = sectionContainer.children.length + 1;

        let sectionHTML = `
            <div class="section-group border p-3 my-2">
            <h5>Section ${sectionIndex}</h5>
            <div>
                <label for="secNo[]" class="form-label mt-4">Section number:</label>
                <input type="text" name="secNo[]" class="form-control" placeholder="Enter section number" required>
            </div>
            <div>
                <label for="secMaxStudent[]" class="form-label mt-4">Maximum students:</label>
                <input type="text" name="secMaxStudent[]" class="form-control" placeholder="Enter max students" required min="1">
            </div>
            <div>
                <label for="sec_lec[]" class="form-label mt-4">Lecturer: (Enter lecturer id)</label>
                <input type="text" name="sec_lec[]" class="form-control" placeholder="Enter lecturer id" required>
            </div>
           `;
           sectionContainer.insertAdjacentHTML('beforeend', sectionHTML);
    }

    function removeSection(button){
        button.parentElement.remove();
    }
</script>
<div class="container mt-4">
    <div class="row">
        <div class="col">
            <h2>Add New Course</h2>

            <?php
            //display success or error message
            if(isset($_SESSION['success'])){
                echo "<div class='alert alert-success'>" .$_SESSION['success']. "</div>";
                unset($_SESSION['success']); 
            } elseif(isset($_SESSION['error'])){
                echo "<div class='alert alert-danger'>" .$_SESSION['error']. "</div>";
                unset($_SESSION['error']); 
            }
            ?>

<form action="addcourse.php" method="POST">
    <fieldset>    
        <div>
            <label for="c_code" class="form-label mt-4">Course code:</label>
            <input type="text" class="form-control" id="c_code" name="c_code" placeholder="Enter course code" required>
        </div>
        <div>
            <label for="c_name" class="form-label mt-4">Course name:</label>
            <input type="text" class="form-control" id="c_name" name="c_name" placeholder="Enter course code" required>
        </div>
        <div>
            <label for="chours" class="form-label mt-4">Course credit:</label>
            <input type="number" class="form-control" id="chours" name="chours" placeholder="Enter course credit hours" required min="2">
        </div>
        <div>
            <label for="sem" class="form-label mt-4">Semester:</label>
            <input type="text" class="form-control" id="sem" name="sem" placeholder="Enter semester" required>
        </div>
        <br>
        <h4 class="mt-4">Course Sections</h4>
        <div id="section-container"></div>
        <button type="button" class="btn btn-secondary mt-3" onclick="addSection()">Add Section</button>
        <br><br>
        <button type="submit" class="btn btn-primary">Add Course</button>
    </fieldset>
</form>