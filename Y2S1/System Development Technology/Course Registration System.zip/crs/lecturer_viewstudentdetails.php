<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'headerlecturer.php';
include 'db_connect.php';

if(!isset($_SESSION['funame'])){
    $_SESSION['error_message'] = "You are not authorized to view this page!";
    header('Location: lecturer_login.php');
    exit();
}

// echo "<pre>";
// print_r($_SESSION);
// echo "</pre>";

//get student id
$lec_id = $_SESSION['funame'];

// if(isset($_GET['course']) || !isset($_GET['section'])) {
//     echo "Course or Section not specified.";
//     exit();
// }

$courseCode = $_GET['course'] ?? '';
$section = $_GET['section'] ?? '';

// $query = "SELECT u.*, GROUP_CONCAT(DISTINCT CONCAT(c.c_code, '-', c.c_name, ' (', c.c_section, ')') ORDER BY c.c_code ASC SEPARATOR '<br>') as courses_enrolled
//           FROM tb_user u
//           LEFT JOIN tb_registration r ON u.u_sno = r.r_student
//           LEFT JOIN tb_course c ON r.r_course = c.c_code
//           WHERE u.u_sno = ? AND c.c_lec = ?
//           GROUP BY u.u_sno";
// $stmt = mysqli_prepare($con, $query);
// mysqli_stmt_bind_param($stmt, "ss", $lec_id, $_SESSION['lec_id']);
// mysqli_stmt_execute($stmt);
// $studentData = mysqli_stmt_get_result($stmt);
// $student = mysqli_fetch_assoc($studentData);

$query = "SELECT u.u_sno, u.u_name, u.u_email, u.u_contact
          FROM tb_user u
          LEFT JOIN tb_registration r ON u.u_sno = r.r_student
          LEFT JOIN tb_course c ON r.r_course = c.c_code
          WHERE c.c_lec = ? AND c.c_code = ? AND c.c_section = ?
          ORDER BY u.u_sno ASC";
$stmt = mysqli_prepare($con, $query);
mysqli_stmt_bind_param($stmt, "sss", $lec_id, $courseCode, $section);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$student = mysqli_fetch_assoc($result);

if(!$student){
    $_SESSION['error_message'] = "No such student found or the student is not enrolled in any of your courses!";
    header('Location: lecturer_viewstudentlist.php');
    exit();
}
?>

    <div class="container mt-4">
        <!-- back button -->
         <div class="mb-4">
            <a href="lecturer_viewstudentdetails.php?course=<?= htmlspecialchars($courseCode); ?>&section=<?= htmlspecialchars($section); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back
            </a>
        </div>

        <div class="row">
            <div class="col-md-6">
                <h2>Student Information</h2>
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <div class="text-center mb-3">
                                    <i class="fas fa-user-circle fa-5x text-primary"></i>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <h4><?= htmlspecialchars($student['u_name']); ?></h4>
                                <p class="text-muted">ID: <?= htmlspecialchars($student['u_sno']); ?></p>
                            </div>
                        </div>

                        <h5 class="mb-3">Personal Information</h5>
                        <div class="row">
                            <div class="col-md-4">
                                <p class="text-muted">Email: <?php echo htmlspecialchars($student['u_email']); ?></p>
                                <p class="text-muted">Contact: <?php echo htmlspecialchars($student['u_contact']); ?></p>
                            </div>
                            <div class="col-md-4">
                            <p class="text-muted">State: <?php echo htmlspecialchars($student['u_state']); ?></p>
                            <p class="text-muted">Registration Date: <?php echo date('d M Y', strtotime($student['u_reg'])); ?></p>
                            </div>
                        </div>

                        <h5 class="mb-3">Courses Enrolled</h5>
                        <div class="courses">
                            <?php echo $student['courses_enrolled'] ?: 'No courses enrolled yet.'; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5>Course Registration Status</h5>
                    </div>
                    <div class="card-body">
                        <?php 
                        $status_query = "SELECT c.c_code, c.c_name, c.c_section, r.r_status
                                        FROM tb_registration r
                                        LEFT JOIN tb_course c ON r.r_course = c.c_code
                                        WHERE r.r_student = ? AND c.c_lec = ?
                                        ORDER BY c.c_code ASC";
                        $status_stmt = mysqli_prepare($con, $status_query);
                        mysqli_stmt_bind_param($status_stmt, "ss", $student_id, $_SESSION['lec_id']);
                        mysqli_stmt_execute($status_stmt);
                        $status_result = mysqli_stmt_get_result($status_stmt);

                        while($status = mysqli_fetch_assoc($status_result)): ?>
                            <div class="mb-3">
                                <p class="mb-1"><?= htmlspecialchars($status['c_code']); ?></p>
                                <p class="mb-1">Section: <?= htmlspecialchars($status['c_section']); ?></p>
                                <span class="badge bg-<?php echo $status['r_status'] == 'Approved' ? 'bg-success' : 
                                                                ($status['r_status'] == 'Rejected' ? 'bg-danger' : 'bg-warning'); ?>">
                                    <?php echo htmlspecialchars($status['r_status']); ?>
                                </span>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        .courses {
            background-color: #f9f9f9;
            padding: 10px;
            border-radius: 5px;
            line-height: 1.5;
        }
    </style>

<?php include 'footer.php'; ?>