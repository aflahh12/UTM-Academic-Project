<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'headerlecturer.php';?>  

<div class="container">

  Lecturer page
  
</div>

<?php include 'footer.php';?>