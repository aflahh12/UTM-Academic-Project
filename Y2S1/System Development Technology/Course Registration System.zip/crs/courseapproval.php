<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'headerlecturer.php';
include 'db_connect.php';

//auto-approve
$query = "SELECT r.r_id, r.r_course, c.c_maxstudent, (SELECT COUNT(*) FROM tb_registration WHERE r_course = r.r_course AND r_status = 'Approved') as enrolled
          FROM tb_registration r
          LEFT JOIN tb_course c ON r.r_course = c.c_code
          WHERE r.r_status = 'Pending'";

$stmt = mysqli_prepare($con, $query);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

while($row = mysqli_fetch_assoc($result)){
    if($row['enrolled'] < $row['c_maxstudent']){
        $update_query = "UPDATE tb_registration SET r_status = 'Approved' WHERE r_id = {$row['r_id']}";
        mysqli_query($con, $update_query);
        error_log("Auto-approved registration ID: {$row['r_id']}");
    }
}

//get all course registrations
$registration_query = "SELECT r.r_id, r.r_course, r.r_student, r.r_status, r.r_section, r.r_sem, c.c_name, c.c_credit, c.c_code, u.u_sno
                       FROM tb_registration r
                       LEFT JOIN tb_course c ON r.r_course = c.c_code
                       LEFT JOIN tb_user u ON r.r_student = u.u_sno
                       ORDER BY r.r_student, r.r_sem DESC";
$registration_result = mysqli_query($con, $registration_query);

//get avail sem
$sem_query = "SELECT DISTINCT r_sem FROM tb_registration ORDER BY r_sem DESC";
$sem_result = mysqli_query($con, $sem_query);
$sem = [];
while($sem_row = mysqli_fetch_assoc($sem_result)){
    $sem[] = $sem_row['r_sem'];
}

//default to latest sem
$selected_sem = $_GET['semester'] ?? ($sem[0] ?? '');

//get latest enrollment
$enroll_query = "SELECT r_course, COUNT(*) AS enrolled_count FROM tb_registration WHERE r_status = 'Approved' GROUP BY r_course";
$enroll_result = mysqli_query($con, $enroll_query);
$enroll = [];
while($enroll_row = mysqli_fetch_assoc($enroll_result)){
    $enroll[$enroll_row['r_course']] = $enroll_row['enrolled_count'];
}

//get max student for courses
$course_max_std_query = "SELECT c_code, c_maxstudent FROM tb_course";
$course_max_std_result = mysqli_query($con, $course_max_std_query);
$course_max_std = [];
while($max = mysqli_fetch_assoc($course_max_std_result)){
    $course_max_std[$max['c_code']] = $max['c_maxstudent'];
}
?>

<div class="container mt-5">
  <div class="d-flex justify-content-between mb-3">
    <a href="lecturer_courseview.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i>Back</a>
    <h2>Course Approval</h2>
    </div>
    
    <div class="card">
      <div class="card-header bg-light">
        <form method="GET" class="d-flex align-items-center">
          <label for="semester" class="me-2">Semester:</label>
          <select name="semester" class="form-select" onchange="this.form.submit()">
            <?php foreach($sem as $s): ?>
              <option value="<?php echo $s; ?>" <?php echo ($selected_sem == $s) ? 'selected' : ''; ?>>Semester<?php echo $s; ?></option>
            <?php endforeach; ?>
          </select>
        </form>
      </div>

      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered table-hover">
            <thead>
              <tr>
                <th>No.</th>
                <th>Student ID</th>
                <th>Student Name</th>
                <th>Course Code</th>
                <th>Course Name</th>
                <th>Credit Hours</th>
                <th>Section</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $i = 1; 
                    while($row = mysqli_fetch_assoc($registration_result)): 
                    if($selected_sem && $row['r_sem'] != $selected_sem) continue; 
                    
                    $curr_enroll = $enroll[$row['r_course']] ?? 0;
                    $max_std = $course_max_std[$row['r_course']] ?? 0;
                    $isFull = $curr_enroll >= $max_std;
              ?>
                <tr>
                  <td><?php echo $i++; ?></td>
                  <td><?php echo $row['u_sno']; ?></td>
                  <td><?php echo $row['r_student']; ?></td>
                  <td><?php echo $row['c_code']; ?></td>
                  <td><?php echo $row['c_name']; ?></td>
                  <td><?php echo $row['c_credit']; ?></td>
                  <td><?php echo $row['r_section']; ?></td>
                  <td>
                    <select class="form-select" name="status" onchange="updateStatus(<?php echo $row['r_id']; ?>, this.value)">
                      <option value="Pending" <?php echo $row['r_status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                      <option value="Approved" <?php echo $row['r_status'] == 'Approved' ? 'selected' : ''; ?>>Approved</option>
                      <option value="Rejected" <?php echo $row['r_status'] == 'Rejected' ? 'selected' : ''; ?>>Rejected</option>
                    </select>
                    <small class="text-muted">
                      Enrolled: <?php echo $curr_enroll; ?> / <?php echo $max_std; ?>
                    </small>
                  </td>
                  <td class="text-center">
                    <?php if($row['r_status'] == 'Pending'): ?>
                      <?php if(!$isFull): ?>
                        <button onclick="autoApprove(<?php echo $row['r_id']; ?>)" class="btn btn-success btn-sm"><i class="fas fa-magic"></i>Auto-Approve</button>
                        <?php else: ?>
                          <span class="badge bg-danger">Course id now full!</span>
                        <?php endif; ?>
                        <?php else: ?>
                          <span class="badge <?php echo ($row['r_status'] == 'Approved') ? 'bg-success' : 'bg-danger';?>">
                            <?php echo ($row['r_status'] == 'Approved') ? 'Approved' : "Rejected"; ?>
                          </span>
                        <?php endif; ?>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <script>
    function updateStatus(id, status){
        confirmAction('Are you sure you want to update this registration status?', function(){
            window.location.href = 'courseregstatus.php?id=' + id + '&status=' + status;
            });
    }

    function autoApprove(id){
        confirmAction('Are you sure you want to auto-approve this registration?', function(){
            window.location.href = 'courseregstatus.php?id=' + id + '&status=Approved';
            });
    }

    function confirmAction(message, callback){
        if(confirm(message)){
            callback();
        }
    }
    </script>

<?php include 'footer.php';?>