<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'headerlecturer.php';
include 'db_connect.php';

//Get user ID
$lec_id = $_SESSION['funame'];

//Retrieve all registerd courses
$semesters = [];
$sem_query = "SELECT DISTINCT c_sem FROM tb_course ORDER BY c_sem DESC";
$sem_result = mysqli_query($con, $sem_query);
while($sem = mysqli_fetch_assoc($sem_result)){
    $semesters[] = $sem['c_sem'];
}

//fetch to latest sem
$latest_sem_query = "SELECT c_sem FROM tb_course ORDER BY c_sem DESC LIMIT 1";
$latest_sem = mysqli_fetch_assoc(mysqli_query($con, $latest_sem_query))['c_sem'];

$selected_sem = isset($_GET['semester']) ? $_GET['semester'] : $latest_sem;
$query = "SELECT c.*, COALESCE((SELECT COUNT(*) FROM tb_registration r WHERE r.r_course = c.c_code AND r.r_status = 2), 0) as enrolled
          FROM tb_course c
          WHERE c.c_lec = ? AND c.c_sem = ?
          ORDER BY c.c_code ASC";

$stmt = mysqli_prepare($con, $query);
mysqli_stmt_bind_param($stmt, "ss", $lec_id, $selected_sem);
mysqli_stmt_execute($stmt);
$courses = mysqli_stmt_get_result($stmt);
?>

<div class="container mt-4">
  <div class="d-flex justify-content-between mb-3">
    <a href="lecturer.php" class="btn btn-secondary">
      <i class="fas fa-arrow-left"></i>Back
    </a>
    <h2>Course List</h2>
  </div>

  <div class="card">
    <div class="card header bg-primary text-white">
      <div class="d-flex justify-content-between align-items-center">
        <h5> Assigned course of semester <?= htmlspecialchars($selected_sem); ?></h5>
        <form method="GET">
          <label class="me-2" for="semester">Semester:</label>
          <select name="semester" id="semester" class="form-select" onchange="this.form.submit()">
            <?php foreach($semesters as $sem): ?>
              <option value="<?php echo $sem; ?>" 
                  <?php echo $selected_sem == $sem ? 'selected' : ''; ?>>
                <?php echo $sem; ?>
              </option>
            <?php endforeach; ?>
          </select>
        </form>
      </div>
    </div>
    <div class="card-body">
      <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th>No.</th>
            <th>Course Code</th>
            <th>Course Name</th>
            <th>Credit Hour</th>
            <th>Enrolled</th>
            <th>Section</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; while($course = mysqli_fetch_assoc($courses)): ?>
            <tr>
              <td><?= $no++; ?></td>
              <td><?= htmlspecialchars($course['c_code']); ?></td>
              <td><?= htmlspecialchars($course['c_name']); ?></td>
              <td><?= htmlspecialchars($course['c_credit']); ?></td>
              <td>
                <?php echo $course['enrolled']; ?>
                <?php if($course['enrolled'] >= $course['c_maxstudent']): ?>
                  <span class="badge bg-danger">Full</span>
                <?php endif; ?>
              </td>
              <td><?= htmlspecialchars($course['c_section']); ?></td>
              <td>
                <a href="lecturer_viewstudentlist.php?code=<?= htmlspecialchars($course['c_code']); ?>&section=<?= htmlspecialchars($course['c_section']); ?>&semester=<?= htmlspecialchars($selected_sem); ?>" 
                   class="btn btn-primary">
                  <i class="fas fa-eye"></i>View Student
                </a>
              </td>
            </tr>
          <?php endwhile; ?>
          <?php if(mysqli_num_rows($courses) == 0): ?>
            <tr>
              <td colspan="7" class="text-center">No course found!</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include 'footer.php';?>