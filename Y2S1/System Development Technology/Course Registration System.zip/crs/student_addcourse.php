<?php 
include('crs_session.php');
// checkUserAccess("2");

if(!session_id())
{
  session_start();
}

include 'headerstudent.php';
include 'db_connect.php';
?>

<div class="container mt-5">
    <h3>Course Registration</h3>

    <!-- <ul class="nav nav-tabs mt-4">
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="student_courseregister.php">Register</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="student_addcourse.php">Course Offered</a>
        </li>
    </ul> -->

    <ul class="nav nav-tabs">
        <li class="nav-item">
            <a class="nav-link" href="student_courseregister.php" >Registered Course</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active">Add new course</a>
        </li>
    </ul>

    <div class="card mt-3">
        <div class="card-header">
            <h4>Student ID: </h4>
            <?php echo isset($_SESSION['funame']) ? $_SESSION['funame'] : 'Not Set'; ?>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-6">
                    <label>Show</label>
                    <select class="form-select form-select-sm w-auto d-inline">
                        <option>10</option>
                        <option>25</option>
                        <option>50</option>
                    </select>
                    <label>entries</label>
                </div>
                <div class="col-md-6">
                    <input type="text" id="search" class="form-control" placeholder="Search..." onkeyup="searchTable()">
                </div>
            </div>

            <form method="POST" action="student_addcourseprocess.php">
                <table class="table table-striped table-hover" id="course_table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Semester</th>
                            <th>Course Code</th>
                            <th>Course Name</th>
                            <th>Credit Hours</th>
                            <th>Section</th>
                            <th>Enrolled</th>
                            <th>Select</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        //fetch courses that are not registered by the student
                        $query = "SELECT c.*, (SELECT COUNT(*) FROM tb_registration r WHERE r_course = c.c_code AND r.r_status = 2) AS enrolled
                                  FROM tb_course c
                                  WHERE c.c_sem = (SELECT MAX(c_sem) FROM tb_course)
                                  ORDER BY c.c_code";
                        $result = mysqli_query($con, $query);
                        $no = 1;
                        $sem = '';

                        while($row = mysqli_fetch_assoc($result)){
                            $sem = $row['c_sem'];
                            $full = ($row['enrolled'] >= $row['c_maxstudent']) ? 'disabled' : '';
                            echo "<tr>";
                            echo "<td>{$no}</td>";
                            echo "<td>{$row['c_sem']}</td>";
                            echo "<td>{$row['c_code']}</td>";
                            echo "<td>{$row['c_name']}</td>";
                            echo "<td>{$row['c_credit']}</td>";
                            echo "<td>{$row['c_section']}</td>";
                            echo "<td>{$row['enrolled']}/{$row['c_maxstudent']}" .($full ? "<span class='badge bg-danger'>Full</span>" : "") . "</td>";
                            echo "<td><input type='checkbox' name='course[]' value='" .$row['c_code'] . "'" .$full . "></td>";
                            echo "</tr>";
                            $no++;
                        }
                        ?>
                    </tbody>
                </table>

                <!-- hidden input -->
                <input type="hidden" name="sem" value="<?php echo $sem; ?>">
                
                <div class="text-center mt-3">
                    <button type="submit" class="btn btn-primary">Register</button>
                </div>
            </form>

            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-<?php echo $_SESSION['message_type']; ?> mt-3">
                    <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    function searchTable(){
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("search");
        filter = input.value.toUpperCase();
        table = document.getElementById("course_table");
        tr = table.getElementsByTagName("tr");

        for(i = 0; i < tr.length; i++){
            td = tr[i].getElementsByTagName("td")[1];
            if(td){
                txtValue = td.textContent || td.innerText;
                if(txtValue.toUpperCase().indexOf(filter) > -1){
                    tr[i].style.display = "";
                }else{
                    tr[i].style.display = "none";
                }
            }
        }
    }
</script>

<?php include 'footer.php'; ?>