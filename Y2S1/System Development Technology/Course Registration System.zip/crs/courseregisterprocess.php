<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'db_connect.php';


//Retrieve data from  form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $uic = $_SESSION['funame']; // User ID
  $fcourse = $_POST['fcourse']; // Course code
  $fsem = $_POST['fsem']; // Semester
  
  // Debug: check if the form data is received correctly
  error_log("Received form data - User: $uic, Course: $fcourse, Semester: $fsem");

  // SQL Insert operation
  $sql = "INSERT INTO tb_registration(r_student, r_course, r_sem, r_status) VALUES (?, ?, ?, '1')";
  $stmt = mysqli_prepare($con, $sql);

  if ($stmt) {
      mysqli_stmt_bind_param($stmt, "sss", $uic, $fcourse, $fsem);
      $result = mysqli_stmt_execute($stmt);

      // Confirmation registration successful or fail
      if ($result) {
          $_SESSION['registration_message'] = "Course registration successful!";
      } else {
          $_SESSION['registration_message'] = "Registration failed. Please try again.";
          error_log("SQL execution error: " . mysqli_error($con)); // Log any SQL execution errors
      }

      mysqli_stmt_close($stmt);
  } else {
      $_SESSION['registration_message'] = "Error preparing SQL query.";
      error_log("SQL preparation error: " . mysqli_error($con)); // Log any SQL preparation errors
  }

  // Close connection
  mysqli_close($con);

  // Redirect to course view
  header('Location: courseview.php');
  exit();
}
?>