<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'db_connect.php';
include 'headeradvisor.php';

//get transaction id
if(isset($_GET['id'])){
    $t_id = $_GET['id'];
} else{
    $_SESSION['error'] = "Invalid transaction ID.";
    header('Location: courselist.php');
    exit();
}

//handle form submission
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    //validate the form data
    if(empty($_POST['semester']) || empty($_POST['course']) || empty($_POST['status'])) {
        $_SESSION['error'] = "All fields are required.";
        header("Location: modifycoursedetails.php?id=$t_id");
        exit();
    }

    //sanitize the inputs
    $semester = trim(mysqli_real_escape_string($con, $_POST['semester']));
    $course = trim(mysqli_real_escape_string($con, $_POST['course']));
    $status = intval($_POST['status']);
    
    //update the course reg
    $update_sql = "UPDATE tb_registration SET r_sem = ?, r_course = ?, r_status = ? WHERE r_id = ?";
    $stmt = mysqli_prepare($con, $update_sql);
    mysqli_stmt_bind_param($stmt, "ssii", $semester, $course, $status, $t_id);

    if(mysqli_stmt_execute($stmt)){
        //update the course name in tb_course
        if($course !== $current_course)




        $_SESSION['success'] = "Course registration details updated successfully.";
        header("Location: courselist.php");
        exit();
    } else {
        $_SESSION['error'] = "Error updating course registration: " .mysqli_error($con);
        header("Location: modifycoursedetails.php?id=$t_id");
        exit();
    }
}
?>
