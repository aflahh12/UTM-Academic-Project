<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'headeradvisor.php';
include 'db_connect.php';

$code = $_GET['code'] ?? '';
$section = $_GET['section'] ?? '';

if($code && $section) {
    $stmt = mysqli_prepare($con, "SELECT * FROM tb_course WHERE c_code = ? AND c_section = ?");
    mysqli_stmt_bind_param($stmt, "ss", $code, $section);
    mysqli_stmt_execute($stmt);
    $course = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(!isset($_POST['confrim']) || $_POST['confirm'] !== 'yes') {
        header("Location: admin_courselist.php");
        exit();
    }

    $stmt = mysqli_prepare($con, "DELETE FROM tb_course WHERE c_code = ? AND c_section = ?");
    mysqli_stmt_bind_param($stmt, "ss", $code, $section);

    $_SESSION['message'] = mysqli_stmt_bind_param($stmt) ? "Course deleted successfully!" : "Error deleting course: " .mysqli_error($con);
    $_SESSION['message_type'] = mysqli_stmt_bind_param($stmt) ? "success" : "danger";

    header("Location: admin_courselist.php");
    exit();
}
?>

<div class="container mt-5">
    <h2>Delete Course</h2>
    <?php if (isset($_SESSION['message'])) : ?>
        <div class="alert alert-<?= $_SESSION['message_type'] ?> alert-dismissible fade show mt-3" role="alert">
            <?= $_SESSION['message']; unset($_SESSION['message'], $_SESSION['message_type']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if($course): ?>
        <div class="card">
            <div class="card-header bg-danger text-white">Confirm Deletion</div>
            <div class="card-body">
                <p>Are you sure you want to delete the course <strong><?= htmlspecialchars($course['c_name']); ?></strong>?</p>
                <form method="POST">
                    <input type="hidden" name="confirm" value="yes">
                    <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i>Delete</button>
                    <a href="admin_courselist.php" class="btn btn-secondary"><i class="fas fa-times"></i>Cancel</a>
                </form>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">Course not found.</div>
        <?php endif; ?>
    </div>

    <?php include 'footer.php'; ?>