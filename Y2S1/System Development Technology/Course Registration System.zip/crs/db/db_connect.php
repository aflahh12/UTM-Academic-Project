<?php
// Set DB Parameter
$servername = "localhost";
$username = "root";
$password = ""; // update with your actual password if needed
$dbname = "db_crs";

// Connect DB
$con = mysqli_connect($servername, $username, $password, $dbname);

//Connection Check (continue as individual project)

?>