<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'headeradvisor.php';
include 'db_connect.php';

//get avail sem
$sem_query = "SELECT DISTINCT c_sem FROM tb_course ORDER BY c_sem DESC";
$sem_result = mysqli_query($con, $sem_query);

//fetch latest sem
$latest_sem_query = "SELECT c_sem FROM tb_course ORDER BY c_sem DESC LIMIT 1";
$latest_sem = mysqli_fetch_assoc(mysqli_query($con, $latest_sem_query))['c_sem'];

if(!$latest_sem){
    $curryear = date('Y');
    $nextyear = date('Y') + 1;
    $currmonth = date('n');
    $sem = ($currmonth <= 6) ? '1' : '2';
    $latest_sem = "$curryear/$nextyear-$sem";
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $course_code = $_POST['course_code'];
    $course_name = $_POST['course_name'];
    $credit_hours = $_POST['credit_hours'];
    $lecturer = strtoupper($_POST['lecturer']);
    $max_students = $_POST['max_students'];
    $semester = $_POST['semester'];
    $section = $_POST['section'];

    //if course w same section exists
    $query = "SELECT * FROM tb_course WHERE c_code = ? AND c_section = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "ss", $course_code, $section);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if(mysqli_num_rows($result) > 0){
        $_SESSION['message'] = "Course with the same section already exists!";
        $_SESSION['message_type'] = "danger";
        header('Location: admin_addcourse.php');
        exit();
    } else{
        $insert_query = "INSERT INTO tb_course (c_code, c_name, c_credit, c_lec, c_maxstudent, c_sem, c_section) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($con, $insert_query);
        mysqli_stmt_bind_param($stmt, "ssisiss", $course_code, $course_name, $credit_hours, $lecturer, $max_students, $semester, $section);

        if(mysqli_stmt_execute($stmt)){
            $_SESSION['message'] = "Course added successfully!";
            $_SESSION['message_type'] = "success";
        } else{
            $_SESSION['message'] = "Error adding course: " .mysqli_error($con);
            $_SESSION['message_type'] = "danger";
        }
    }
}

?>

<div class="container mt-5">

    <div class="d-flex justfy-content-between mb-3">
        <a href="javascript:history.back()" class="btn btn-secondary"><i class="fas fa-arrow-left"></i>Back</a>
        <h2>Add Course</h2>
    </div>

    <?php if(!empty($_SESSION['message'])): ?>
    <div class="alert alert-<?= htmlspecialchars($_SESSION['message_type']) ?> alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($_SESSION['message']); unset($_SESSION['message'], $_SESSION['message_type']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <div class="card mt-4">
        <div class="card-header bg-primary text-white">
            <h4>Course list</h4>
        </div>
        <div class="card-body">
            <form action="" method="POST">
                <div class="mb-3">
                    <label for="course_code" class="form-label">Course Code</label>
                    <input type="text" class="form-control" id="course_code" name="course_code" required>
                </div>
                <div class="mb-3">
                    <label for="course_name" class="form-label">Course Name</label>
                    <input type="text" class="form-control" id="course_name" name="course_name" required>
                </div>
                <div class="mb-3">
                    <label for="credit_hours" class="form-label">Credit Hours</label>
                    <select class="form-select" id="credit-hours" name="credit_hours" required>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="lecturer" class="form-label">Lecturer</label>
                    <input type="text" class="form-control" id="lecturer" name="lecturer" required>
                </div>
                <div class="mb-3">
                    <label for="max_students" class="form-label">Max Students</label>
                    <input type="number" class="form-control" id="max_students" name="max_students" required>
                </div>
                <div class="mb-3">
                    <label for="semester" class="form-label">Semester</label>
                    <select class="form-select" id="semester" name="semester" required>
                        <?php while($row = mysqli_fetch_assoc($sem_result)): ?>
                        <option value="<?= htmlspecialchars($row['c_sem']); ?>" <?= $row['c_sem'] == $latest_sem ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($row['c_sem']); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="section" class="form-label">Section</label>
                    <input type="text" class="form-control" id="section" name="section" required>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i>Add Course</button>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>