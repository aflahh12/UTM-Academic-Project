<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'db_connect.php';
include 'headerstudent.php';

$student_id = $_SESSION['u_sno'];

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = isset($_POST['name']) ? $_POST['name'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $contact = isset($_POST['contact']) ? $_POST['contact'] : '';
    $state = isset($_POST['state']) ? $_POST['state'] : '';

    $update_query = "UPDATE tb_user SET u_name = ?, u_email = ?, u_contact = ?, u_state = ? WHERE u_sno = ?";
    $stmt = mysqli_prepare($con, $update_query);
    mysqli_stmt_bind_param($stmt, "sssss", $name, $email, $contact, $state, $uic);

    if(mysqli_stmt_execute($stmt)){
        //reload the updated user data
        $query = "SELECT u_name, u_email, u_contact, u_state FROM tb_user WHERE u_sno = ?";
        $stmt = mysqli_prepare($con, $query);
        mysqli_stmt_bind_param($stmt, "s", $uic);
        mysqli_stmt_execute($stmt);
        $user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        echo "<script>alert('Profile updated successfully!');</script>";
    } else {
        echo "<script>alert('Error updating profile: " .mysqli_error($con). "');</script>";
    }
}
    //fetch user data from database to display
    $query = "SELECT u_name, u_email, u_contact, u_state FROM tb_user WHERE u_sno = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "s", $uic);
    mysqli_stmt_execute($stmt);
    $user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

?>

<div class="container mt-4">
    <h2>Edit Profile</h2>
    <form method="POST" action="">
        <div class="mb-3">
            <label for="fname" class="form-label">Full Name</label>
            <input type="text" class="form-control" id="fname" name="name" value="<?php echo htmlspecialchars($user['u_name'] ?? ''); ?>" required>
        </div>
        <div class="mb-3">
            <label for="femail" class="form-label">Email</label>
            <input type="email" class="form-control" id="femail" name="email" value="<?php echo htmlspecialchars($user['u_email'] ?? ''); ?>" required>
        </div>
        <div class="mb-3">
            <label for="fcontact" class="form-label">Contact</label>
            <input type="text" class="form-control" id="fcontact" name="contact" value="<?php echo htmlspecialchars($user['u_contact'] ?? ''); ?>" required>
        </div>
        <div class="mb-3">
            <label for="fstate" class="form-label">State</label>
            <select name="state" class="form-select" required>
                <?php $states = ["Johor", "Kedah", "Kelantan", "Melaka", "Negeri Sembilan", "Pahang", "Perak", "Perlis", "Pulau Pinang", "Sabah", "Sarawak", "Selangor", "Terengganu", "WP Kuala Lumpur", "WP Labuan", "WP Putrajaya"]; 
                foreach($states as $state): ?>
                <option value="<?php echo $state; ?>" <?php echo (($user['u_state'] ?? '') == $state) ? "selected": ""; ?>><?php echo $state; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Update Profile</button>
    </form>
</div>
<?php include 'footer.php'; ?>