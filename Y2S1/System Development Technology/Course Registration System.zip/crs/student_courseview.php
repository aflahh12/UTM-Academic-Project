<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'headerstudent.php';
include 'db_connect.php';

//Get user ID
$uic = $_SESSION['funame'];

//retrieve sem for the current student
$sem_query = "SELECT DISTINCT r_sem FROM tb_registration WHERE r_student = '$uic' ORDER BY r_sem DESC";
$sem_result = mysqli_query($con, $sem_query);
?>

<div class="container mt-5">
  <?php while ($sem = mysqli_fetch_assoc($sem_result)) : ?>
    <h5 class="mb-3">Semester: <?= htmlspecialchars($sem['r_sem']); ?></h5>

    <table class="table table-hover">
      <thead class="table-light">
        <tr>
          <th>Course Code</th>
          <th>Course Name</th>
          <th>Credit</th>
          <th>Section</th>
          <th>Course Status</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $total_credit = 0;
        $query = "SELECT r.r_course, r.r_section, c.c_name, c.c_credit, s.s_desc FROM tb_registration r
                  LEFT JOIN tb_course c ON r.r_course = c.c_code
                  LEFT JOIN tb_status s ON r.r_status = s.s_id
                  WHERE r_student = '$uic' AND r.r_sem = '{$sem['r_sem']}'";
        $result = mysqli_query($con, $query);
        while ($course = mysqli_fetch_assoc($result)) :
          $total_credit += $course['c_credit'];
        ?>
          <tr>
            <td><?= htmlspecialchars($course['r_course']); ?></td>
            <td><?= htmlspecialchars($course['c_name']); ?></td>
            <td><?= htmlspecialchars($course['c_credit']); ?></td>
            <td><?= htmlspecialchars($course['r_section']); ?></td>
            <td><?= htmlspecialchars($course['s_desc']); ?></td>
          </tr>
        <?php endwhile; ?>
        <tr>
          <td colspan="3" class="text-end">Total Semester Credit:</td>
          <td class="fw-bold"><?= htmlspecialchars($total_credit); ?></td>
        </tr>
      </tbody>
    </table>
  <?php endwhile; ?>

<?php include 'footer.php';?>