<?php include 'headermain.php';?>  
<div class="container">
  
  <br><br><h5>Please fill to login<h5>
  <form method="POST" action="login_process.php">
  <fieldset>
    <div>
      <label for="exampleInputEmail1" class="form-label mt-4">Enter your staff or student id</label>
      <input type="text" name="funame" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your staff or student ID" required>
    </div>

    <div>
      <label for="exampleInputPassword1" class="form-label mt-4">Enter password</label>
      <input type="password" name="fpwd" class="form-control" id="exampleInputPassword1" placeholder="Create password" autocomplete="off" required>
    </div>
   
    <br><br>
    <button type="submit" class="btn btn-primary">Login</button>
    <br><br><br>
  </fieldset>
</form>
</div>

<?php
if(isset($_SESSION['message'])){
  echo "<div class='alert alert-info'>" .$_SESSION['message']. "</div>";
  unset($_SESSION['message']);
}

?>

<?php include 'footer.php';?>