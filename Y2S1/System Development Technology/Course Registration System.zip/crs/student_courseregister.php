<?php 
include('crs_session.php');
// checkUserAccess("2");

if(!session_id())
{
  session_start();
}

include 'headerstudent.php';
include 'db_connect.php';

//Get user ID
$uic = $_SESSION['funame'];

//get all sem
$sem_query = "SELECT DISTINCT c_sem FROM tb_course ORDER BY c_sem DESC";
$sem_result = mysqli_query($con, $sem_query);

//fetch latest sem
$latest_sem_query = "SELECT c_sem FROM tb_course ORDER BY c_sem DESC LIMIT 1";
$latest_sem = mysqli_fetch_assoc(mysqli_query($con, $latest_sem_query))['c_sem'];

//determine selected sem
$currsem = $_GET['semester'] ?? $latest_sem;

//retrieve courses for the selected sem
$course_query = "SELECT r.*, c.*, (SELECT COUNT(*) FROM tb_registration WHERE r_course = r.r_course AND r_section = r.r_section AND r_status = 2) as enrolled
                 FROM tb_registration r
                 LEFT JOIN tb_course c ON r.r_course = c.c_code
                 WHERE r.r_student = ? AND c.c_sem = ?";
$stmt = mysqli_prepare($con, $course_query);
mysqli_stmt_bind_param($stmt, "ss", $uic, $currsem);
mysqli_stmt_execute($stmt);
$registered_courses = mysqli_stmt_get_result($stmt);

//get total credit for the semester
$total_credit = 0;
?>

<div class="container mt-4">
    <?php if(!empty($_SESSION['message'])): ?>
        <div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
            <?= $_SESSION['message']; ?>
            <?php unset($_SESSION['message'], $_SESSION['message_type']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <h2>Course Registration</h2>

    <ul class="nav nav-tabs">
        <li class="nav-item">
            <a class="nav-link active">Registered Course</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="student_addcourse.php">Add new course</a>
        </li>
    </ul>

    <div class="card mt-3">
        <div class="card-header">
            <h5>
                Student ID: <?= $uic; ?>
                <form method="GET" class="d-inline float-end">
                    <select name="semester" class="form-select" onchange="this.form.submit()">
                        <?php while($sem = mysqli_fetch_assoc($sem_result)): ?>
                            <option value="<?= $sem['c_sem']; ?>" <?= $currsem == $sem['c_sem'] ? 'selected' : ''; ?>>
                                <?= $sem['c_sem']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </form>
            </h5>
        </div>

        <div class="card-body">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Transaction ID</th>
                        <th>Semester</th>
                        <th>Course Code</th>
                        <th>Course Name</th>
                        <th>Credit</th>
                        <th>Section</th>
                        <th>Enrolled</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; while($row = mysqli_fetch_assoc($registered_courses)): ?>
                        <tr>
                            <td><?= $i++; ?></td>
                            <td><?= $row['r_id']; ?></td>
                            <td><?= $row['c_sem']; ?></td>
                            <td><?= $row['c_code']; ?></td>
                            <td><?= $row['c_name']; ?></td>
                            <td><?= $row['c_credit']; ?></td>
                            <td><?= $row['r_section']; ?></td>
                            <td><?= $row['enrolled']; ?></td>
                            <td><?= $row['r_status']; ?></td>
                            <td>
                                <a href="student_editcourse.php?course=<?= $row['r_id']; ?>" class="btn btn-primary btn-sm">Edit</a>
                                <a href="student_dropcourse.php?tid=<?= $row['r_id']; ?>" class="btn btn-danger btn-sm">Drop</a>
                            </td>
                        </tr>
                        <?php $total_credit += $row['c_credit']; ?>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <div class="text-end mt-3">
            <p>Total credit hours: <?= $total_credit; ?></p>
        </div>
    </div>
</div>

<!-- delete confirmation -->
<script>
    function confirmDelete(tid) {
        if(confirm('Are you sure you want to delete this course?')) {
            window.location.href = 'student_dropcourse.php?tid=' + tid;
        }
    }
</script>

<?php include 'footer.php'; ?>