<?php 
include('crs_session.php');
// checkUserAccess("2");

if(!session_id())
{
  session_start();
}

include 'headerstudent.php';
include 'db_connect.php';

//validate the request
if(!isset($_GET['tid'])) {
    $_SESSION['message'] = "Invalid request!";
    $_SESSION['message_type'] = "danger";
    header('Location: student_courseregister.php');
    exit();
}

$transactionID = $_GET['tid'];

//delete course registration
$delete_query = "DELETE FROM tb_registration WHERE r_id = ?";
$stmt = mysqli_prepare($con, $delete_query);
mysqli_stmt_bind_param($stmt, "i", $transactionID);

if(mysqli_stmt_execute($stmt)){
    $_SESSION['message'] = "Course registration deleted successfully!";
    $_SESSION['message_type'] = "success";
    header('Location: student_courseregister.php');
    exit();
} else {
    $_SESSION['message'] = "Error deleting course registration: " .mysqli_error($con);
    $_SESSION['message_type'] = "danger";
    header('Location: student_courseregister.php');
    exit();
}

header('Location: student_courseregister.php');
exit();
?>