<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'headerstudent.php';
include 'db_connect.php';

//Get user ID
$uic = $_SESSION['funame'];

//Retrieve all registerd courses
$sql = "SELECT * FROM tb_course
        LEFT JOIN tb_user ON tb_course.c_lec = tb_user.u_sno";
        
$search_course = isset($_GET['search_course']) ? mysqli_real_escape_string($con, $_GET['search_course']) : '';

if($search_course) {
  $sql .= "AND (tb_course.c_name LIKE '%$search_course%' OR tb_course.c_code LIKE '%$search_course%')";
}


//Execute SQL statement 
$result = mysqli_query($con,$sql);
?>

<div class="container">
  
  <br><br><h5>Course Registration Form<h5>
  <form method="POST" action="courseregisterprocess.php">
  
  <!-- search course available -->
  <!-- <br>
<form class="course" action="/courselist.php" style="margin:auto; max-width:300px; display: flex">
  <input type="text" placeholder="Search courses" name="search_course">
  <button type="submit"><i class="fa fa-search"></i></button>
</form> <br> -->

  <!--show courses available-->
  <table class="table table-hover table-secondary">
  <thead>
    <tr>
      <th scope="col">Course Code</th>
      <th scope="col">Course Title</th>
      <th scope="col">Credit Hours</th>
      <th scope="col">Lecturer</th>
    </tr>
  </thead>
  <tbody>
    <?php
      while($row = mysqli_fetch_array($result))
      {
        echo"<tr>";
        echo"<td>".$row['c_code']."</td>";
        echo"<td>".$row['c_name']."</td>";
        echo"<td>".$row['c_credit']."</td>";
        echo"<td>".$row['u_name']."</td>";
        echo"<tr>";
      }
    ?>
  </tbody>
  </table>
  
  <!-- register course -->
  <fieldset>
    <div>
      <label for="fcourse" class="form-label mt-4">Select Course</label>
      <select class="form-select" name="fcourse" id="fcourse" required>
      <?php
      $sql="SELECT * FROM tb_course";
      $result=mysqli_query($con,$sql);
      while($row=mysqli_fetch_array($result))
      {
        echo"<option value='".$row['c_code']."'>".$row['c_name']."</option>";
      }
      ?>
    </select>    
    </div>

    <div>
      <label for="fsem" class="form-label mt-4">Select Semester</label>
      <select class="form-select" name="fsem" id="fsem" required>
        <option>2024/2025-1</option>
        <option>2024/2025-2</option>
        <option>2024/2025-3</option>
      </select>
    </div><br>
   
    <br><br>
    <button type="submit" class="btn btn-primary">Register</button>
    <button type="reset" class="btn btn-primary">Clear Form</button>
    <br><br><br>
  </fieldset>
</form>
</div>

<?php include 'footer.php';?>