<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

if(!isset($_SESSION['u_utype']) || $_SESSION['u_utype'] != 3){
    $_SESSION['error'] = "Unauthorized access";
    header('Location: login.php');
    exit();
}

//debug log
error_log("POST Data: " .print_r($_POST, true));

//validate required field
if(empty($_POST['fcode']) || empty($_POST['fname']) || empty($_POST['fcredit']) || empty($_POST['fsem'])){
    $_SESSION['error'] = "All fields are required.";
    header('Location: addcourse.php');
    exit();
}

//sanitize inputs
$ccode = trim(mysqli_real_escape_string($con, $_POST['fcode']));
$cname = trim(mysqli_real_escape_string($con, $_POST['fname']));
$chours= intval($_POST['fcredit']);
$sem = trim(mysqli_real_escape_string($con, $_POST['fsem']));

//retrieve section
$sec_no = $_POST['sec_no'];
$sec_max = $_POST['sec_max'];
$sec_lec = $_POST['sec_lec'];

//validate section
if(empty($sec_no) || empty($sec_max) || empty($sec_lec)){
    $_SESSION['error'] = "Please add at least one section.";
    header('Location: addcourse.php');
    exit();
}

//start transactions
mysqli_begin_transaction($con);

try{
    //check if the course already exists
    $checkCourseQuery = "SELECT c_code FROM tb_course WHERE c_code = ?";
    $stmt = mysqli_prepare($con, $checkCourseQuery);
    mysqli_stmt_bind_param($stmt, "s", $ccode);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if(mysqli_num_rows($result) > 0){
        throw new Exception("Course code already exists.");
    }

    $insertCourseQuery = "INSERT INTO tb_course (c_code, c_name, c_credit, c_sem) VALUES (?,?,?,?)";
    $stmt = mysqli_prepare($con, $insertCourseQuery);
    mysqli_stmt_bind_param($stmt, "ssis", $ccode, $cname, $chours, $sem);

    if(!mysqli_stmt_execute($stmt)){
        throw new Exception("Error inserting course: " .mysqli_stmt_error($stmt));
    }

    //insert section
    for ($i=0; $i<count($sec_no); $i++){
        $secNo = trim($sec_no[$i]);
        $secMaxStudent = intval($sec_max[$i]);
        $sec_lec = trim($sec_lec[$i]);

        $insertSectionQuery = "INSERT INTO tb_section (sec_coursecode, sec_no, sec_maxstudent, sec_sem, sec_lec)
                                VALUES (?,?,?,?,?)";
        $stmt = mysqli_prepare($con, $insertSectionQuery);
        mysqli_stmt_bind_param($stmt, "ssiss", $ccode, $secNo, $secMaxStudent, $sem, $sec_lec);

        if(!mysqli_stmt_execute($stmt)){
            throw new exception("Error inserting section " .($i+1). ": " .mysqli_stmt_error($stmt));
        }
        mysqli_stmt_close($stmt);
    }

    //commit transaction
    mysqli_commit($con);
    $_SESSION['success'] = "Course and sections added successfully!";
    header("Location: addcourse.php?status=success");
    exit();
} catch (Exception $e){
    mysqli_rollback($con);
    $_SESSION['error'] = "Error: " .$e->getMessage();
    header('Location: addcourse.php');
    exit();
} finally{
    mysqli_stmt_close($stmt);
    mysqli_close($con);
}

?>