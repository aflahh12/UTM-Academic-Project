<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'headeradvisor.php';
include 'db_connect.php';

//get transaction id
if(isset($_GET['id'])) {
    $t_id = $_GET['id'];
} else {
    $_SESSION['error'] = "Invalid transaction ID.";
    header('Location: courselist.php');
    exit();
}

//fetch current course reg based on the transaction id
$sql = "SELECT * FROM tb_registration
        LEFT JOIN tb_user ON tb_registration.r_student = tb_user.u_sno
        LEFT JOIN tb_course ON tb_registration.r_course = tb_course.c_code
        LEFT JOIN tb_status ON tb_registration.r_status = tb_status.s_id
        WHERE r_id = ?";

$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, "i", $t_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Transaction not found.";
    header('Location: courselist.php');
    exit();
}

$row = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);
?>

<div class="container">
    <h2>Modify Course Registration Details</h2>

    <!-- display error message -->
     <?php
     if(isset($_SESSION['success'])){
        echo "<div class='alert alert-success'>" .$_SESSION['success']. "</div>";
        unset($_SESSION['success']);
     } elseif(isset($_SESSION['error'])){
        echo "<div class='alert alert-danger'>" .$_SESSION['error']. "</div>";
        unset($_SESSION['success']);
     }
     ?>

     <!-- modify course details -->
     <form action="modifycoursedetailsprocess.php?id=<?php echo $t_id;?>" method="POST">
        <div class="form-group">
            <label for="semester" class="form-label mt-4">Semester</label>
            <input type="text" class="form-control" id="semester" name="semester" value="<?php echo htmlspecialchars($row['r_sem']);?>" placeholder="Enter semester" required>
        </div>
        <div class="form-group">
            <label for="course" class="form-label mt-4">Course</label>
            <input type="text" class="form-control" id="course" name="course" value="<?php echo htmlspecialchars($row['r_course']);?>" placeholder="Enter course code" required>
        </div>
        <div class="form-group">
            <label for="course_name" class="form-label mt-4">Course Name</label>
            <input type="text" class="form-control" id="course_name" name="course_name" value="<?php echo htmlspecialchars($row['c_name']);?>" placeholder="Enter course name" required>
        </div>
        <div class="form-group">
            <label for="status" class="form-label mt-4">Status</label>
            <select class="form-select" id="status" name="status" required>
                <option value="1" <?php echo ($row['r_status'] == 1)? 'selected' : '';?>>Received</option>
                <option value="2" <?php echo ($row['r_status'] == 2)? 'selected' : '';?>>Approved</option>
                <option value="3" <?php echo ($row['r_status'] == 3)? 'selected' : '';?>>Rejected</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
        <a href="courselist.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?php include 'footer.php'; ?>