<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'headerstudent.php';
include 'db_connect.php';

$tid = $_GET['tid'] ?? null;
$status = $_GET['status'] ?? null; 
$mode = $_GET['mode'] ?? 'manual';

if($tid && $status){
    error_log("Updating registration ID: $tid to status: $status (Mode: $mode)");
    $query = "SELECT r.r_course, c.c_maxstudent, COUNT(CASE WHEN r_status = 'Approved' THEN 1 END) as enrolled
              FROM tb_registration r
              LEFT JOIN tb_course c ON r.r_course = c.c_code
              WHERE r.r_id = ?";

    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "i", $tid);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $course_info = $result ? mysqli_fetch_assoc($result) : null;

    if($course_info){
        if($status === 'Approved' && $mode === 'auto' && $course_info['enrolled'] >= $course_info['c_maxstudent']){
            $_SESSION['message'] = "Error updating registration: Course is full!";
            $_SESSION['message_type'] = "warning";
            error_log("Error updating registration: Course is full!");
        } else {
        $update_stmt = mysqli_prepare($con, "UPDATE tb_registration SET r_status = ? WHERE r_id = ?");
        mysqli_stmt_bind_param($update_stmt, "si", $status, $tid);

        if(mysqli_stmt_execute($update_stmt)){
            $messages = [
                'Approved' => "Your course registration for {$course_info['r_course']} has been approved!",
                'Rejected' => "Your course registration for {$course_info['r_course']} has been rejected."
            ];

            $student_id = $course_info['r_student'] ?? '';

            if(isset($messages[$status])){
                $notify_stmt = mysqli_prepare($con, "INSERT INTO tb_notification (n_user, n_message, n_type, n_reasons) VALUES (?, ?, ?, ?)");
                $reasons = $_POST['reject_reasons'] ?? null;
                mysqli_stmt_bind_param($notify_stmt, "ssss", $student_id, $messages[$status], $status, $reasons);
                mysqli_stmt_execute($notify_stmt);
            }

            $_SESSION['message'] = "Registration has been $status";
            $_SESSION['message_type'] = "success";
            error_log("Registration ID: $tid has been updated to status: $status");
        } else {
            $_SESSION['message'] = "Error updating registration: " .mysqli_error($con);
            $_SESSION['message_type'] = "danger";
            error_log("Error updating registration: " .mysqli_error($con));
        }
    } 
} else {
        $_SESSION['message'] = "Invalid registration ID or data not found.";
        $_SESSION['message_type'] = "danger";
        error_log("Invalid registration id: $tid");
    }
}

if(isset($_SESSION['message'])) error_log("Session message: " .$_SESSION['message']);

header("Location: courseapproval.php");
exit();
?>