<?php 
include('crs_session.php');

if(!session_id())
{
  session_start();
}

include 'headeradvisor.php';
include 'db_connect.php';

//check if user is admin
// if($_SESSION['u_utype'] != 3){
//     $_SESSION['error'] = "Unauthorized access";
//     header('Location: login.php');
//     exit();
// }

//fetch quick statistics
$totalStudents = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as count FROM tb_user WHERE u_utype = 1"))['count'];
$totalCourses = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as count FROM tb_course"))['count'];
$totalRegistrations = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as count FROM tb_registration"))['count'];

?>

<div class="container mt-5">
    <h3 class="mb-4">Admin Dashboard</h3>

    <!-- quick statistics -->
    <div class="row text-center mb-4">
        <div class="col-md-4">
            <div class="card bg-primary text-white p-3">
                <h5>Total Students</h5>
                <h3><?= $totalStudents; ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-success text-white p-3">
                <h5>Total Courses</h5>
                <h3><?= $totalCourses; ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-warning text-white p-3">
                <h5>Total Registrations</h5>
                <h3><?= $totalRegistrations; ?></h3>
            </div>
        </div>
    </div>

    







<!-- <div class="container">

  Admin page
  
</div> -->

<?php include 'footer.php';?>