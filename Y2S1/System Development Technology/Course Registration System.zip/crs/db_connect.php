<?php
// Set DB Parameter
// $host = "sql307.infinityfree.com";
// $port = "3306";
// $user = "if0_38215923";
// $password = "Naa43439"; // update with your actual password if needed
// $dbname = "if0_38215923_db_crs";

$host = "localhost";
$user = "root";
$password = ""; // update with your actual password if needed
$dbname = "db_crs";

// Connect DB
$con = mysqli_connect($host, $user, $password, $dbname);

//Connection Check (continue as individual project)
if($con->connect_error){
    die("Connection failed: ".$con->connect_error);
}
echo "Connected successfully.";
?>